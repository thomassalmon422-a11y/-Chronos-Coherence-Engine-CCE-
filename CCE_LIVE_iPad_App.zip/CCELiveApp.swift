import SwiftUI

@main
struct CCELiveApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
